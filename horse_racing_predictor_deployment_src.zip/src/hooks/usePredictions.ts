// src/hooks/usePredictions.ts with cache implementation
"use client";

import { useState, useEffect } from 'react';
import { SavedPrediction, PredictionInput } from '@/lib/types';
import { withCache } from '@/lib/cache';

// Cache key generator functions
const generateFetchPredictionsKey = () => 'predictions_all';
const generatePredictionByIdKey = (id: string) => `prediction_${id}`;

export function usePredictions() {
  const [predictions, setPredictions] = useState<SavedPrediction[]>([]);
  const [metrics, setMetrics] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Cached API functions
  const fetchPredictionsFromApi = withCache(
    async () => {
      const response = await fetch('/api/predictions');
      const data = await response.json();
      
      if (data.success) {
        return {
          predictions: data.data.predictions,
          metrics: data.data.metrics
        };
      } else {
        throw new Error(data.error || 'Failed to fetch predictions');
      }
    },
    generateFetchPredictionsKey,
    60 // Cache for 1 minute
  );

  // Fetch all predictions
  const fetchPredictions = async () => {
    setLoading(true);
    setError(null);
    
    try {
      const data = await fetchPredictionsFromApi();
      setPredictions(data.predictions);
      setMetrics(data.metrics);
    } catch (err) {
      setError('An error occurred while fetching predictions');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  // Create a new prediction
  const createPrediction = async (input: PredictionInput) => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await fetch('/api/predictions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ input }),
      });
      
      const data = await response.json();
      
      if (data.success) {
        // Invalidate the predictions cache
        await fetchPredictions();
        return data.data;
      } else {
        setError(data.error || 'Failed to create prediction');
        return null;
      }
    } catch (err) {
      setError('An error occurred while creating prediction');
      console.error(err);
      return null;
    } finally {
      setLoading(false);
    }
  };

  // Get prediction by ID with caching
  const getPredictionById = withCache(
    async (id: string) => {
      const response = await fetch(`/api/predictions/${id}`);
      const data = await response.json();
      
      if (data.success) {
        return data.data;
      } else {
        throw new Error(data.error || 'Failed to fetch prediction');
      }
    },
    generatePredictionByIdKey,
    300 // Cache for 5 minutes
  );

  // Update prediction with actual results
  const updatePredictionResult = async (id: string, actualPosition: number) => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await fetch(`/api/predictions/${id}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ actualPosition }),
      });
      
      const data = await response.json();
      
      if (data.success) {
        // Update the prediction in the local state
        setPredictions(prevPredictions => 
          prevPredictions.map(p => 
            p.id === id ? data.data : p
          )
        );
        
        // Invalidate caches
        await fetchPredictions();
        return data.data;
      } else {
        setError(data.error || 'Failed to update prediction');
        return null;
      }
    } catch (err) {
      setError('An error occurred while updating prediction');
      console.error(err);
      return null;
    } finally {
      setLoading(false);
    }
  };

  // Delete a prediction
  const deletePrediction = async (id: string) => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await fetch(`/api/predictions/${id}`, {
        method: 'DELETE',
      });
      
      const data = await response.json();
      
      if (data.success) {
        // Remove the prediction from the local state
        setPredictions(prevPredictions => 
          prevPredictions.filter(p => p.id !== id)
        );
        
        // Invalidate caches
        await fetchPredictions();
        return true;
      } else {
        setError(data.error || 'Failed to delete prediction');
        return false;
      }
    } catch (err) {
      setError('An error occurred while deleting prediction');
      console.error(err);
      return false;
    } finally {
      setLoading(false);
    }
  };

  // Load predictions on initial mount
  useEffect(() => {
    fetchPredictions();
  }, []);

  return {
    predictions,
    metrics,
    loading,
    error,
    fetchPredictions,
    getPredictionById,
    createPrediction,
    updatePredictionResult,
    deletePrediction,
  };
}
