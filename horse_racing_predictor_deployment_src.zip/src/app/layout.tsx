// src/app/layout.tsx
import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import { MonitoringProvider } from "@/components/MonitoringProvider";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "Horse Racing Predictor",
  description: "Predict horse race outcomes with machine learning",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <MonitoringProvider>
          <div className="min-h-screen flex flex-col">
            <Navbar />
            <main className="flex-grow container-custom py-8">
              {children}
            </main>
            <Footer />
          </div>
        </MonitoringProvider>
      </body>
    </html>
  );
}
