// src/app/api/test/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { generatePrediction } from '@/lib/prediction';
import { generateSamplePredictionInput, validatePredictionInput } from '@/lib/test-utils';

export async function GET() {
  try {
    // Generate a sample prediction input
    const sampleInput = generateSamplePredictionInput();
    
    // Validate the input
    const validation = validatePredictionInput(sampleInput);
    
    // Generate a prediction if input is valid
    const predictionResult = validation.isValid 
      ? generatePrediction(sampleInput) 
      : null;
    
    return NextResponse.json({
      success: true,
      data: {
        sampleInput,
        validation,
        predictionResult
      }
    });
  } catch (error) {
    console.error('Error in test endpoint:', error);
    return NextResponse.json(
      { success: false, error: 'Test endpoint failed' },
      { status: 500 }
    );
  }
}
