// src/app/api/predictions/[id]/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { getPredictionById, updatePredictionResult, deletePrediction } from '@/lib/db';

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const id = params.id;
    const prediction = getPredictionById(id);
    
    if (!prediction) {
      return NextResponse.json(
        { success: false, error: 'Prediction not found' },
        { status: 404 }
      );
    }
    
    return NextResponse.json({
      success: true,
      data: prediction
    });
  } catch (error) {
    console.error(`Error fetching prediction ${params.id}:`, error);
    return NextResponse.json(
      { success: false, error: 'Failed to fetch prediction' },
      { status: 500 }
    );
  }
}

export async function PATCH(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const id = params.id;
    const body = await request.json();
    const { actualPosition } = body;
    
    if (actualPosition === undefined || typeof actualPosition !== 'number') {
      return NextResponse.json(
        { success: false, error: 'Invalid actualPosition value' },
        { status: 400 }
      );
    }
    
    const updatedPrediction = updatePredictionResult(id, actualPosition);
    
    if (!updatedPrediction) {
      return NextResponse.json(
        { success: false, error: 'Prediction not found' },
        { status: 404 }
      );
    }
    
    return NextResponse.json({
      success: true,
      data: updatedPrediction
    });
  } catch (error) {
    console.error(`Error updating prediction ${params.id}:`, error);
    return NextResponse.json(
      { success: false, error: 'Failed to update prediction' },
      { status: 500 }
    );
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const id = params.id;
    const success = deletePrediction(id);
    
    if (!success) {
      return NextResponse.json(
        { success: false, error: 'Prediction not found' },
        { status: 404 }
      );
    }
    
    return NextResponse.json({
      success: true,
      message: 'Prediction deleted successfully'
    });
  } catch (error) {
    console.error(`Error deleting prediction ${params.id}:`, error);
    return NextResponse.json(
      { success: false, error: 'Failed to delete prediction' },
      { status: 500 }
    );
  }
}
