// src/app/api/predictions/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { getAllPredictions, savePrediction, getPerformanceMetrics } from '@/lib/db';
import { generatePrediction } from '@/lib/prediction';
import { PredictionInput } from '@/lib/types';

export async function GET() {
  try {
    const predictions = getAllPredictions();
    const metrics = getPerformanceMetrics();
    
    return NextResponse.json({
      success: true,
      data: {
        predictions,
        metrics
      }
    });
  } catch (error) {
    console.error('Error fetching predictions:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to fetch predictions' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const input: PredictionInput = body.input;
    
    if (!input || !input.race || !input.horse || !input.jockeyTrainer) {
      return NextResponse.json(
        { success: false, error: 'Invalid input data' },
        { status: 400 }
      );
    }
    
    // Generate prediction
    const predictionResult = generatePrediction(input);
    
    // Save prediction to database
    const savedPrediction = savePrediction({
      date: new Date().toISOString().split('T')[0],
      horseName: input.horse.horse_name,
      track: input.race.track,
      predictedPosition: predictionResult.predictedPosition,
      odds: input.jockeyTrainer.sp_odds,
      input,
      output: predictionResult
    });
    
    return NextResponse.json({
      success: true,
      data: savedPrediction
    });
  } catch (error) {
    console.error('Error creating prediction:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to create prediction' },
      { status: 500 }
    );
  }
}
