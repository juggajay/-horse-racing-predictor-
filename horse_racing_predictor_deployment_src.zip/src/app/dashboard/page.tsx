"use client";

import { useState, useEffect } from 'react';
import { usePredictions } from '@/hooks/usePredictions';
import LoadingSpinner from '@/components/ui/LoadingSpinner';

// Dynamic imports for chart components
let Chart;
let chartComponents;

export default function Dashboard() {
  const { predictions, metrics, loading, error } = usePredictions();
  const [monthlyPerformance, setMonthlyPerformance] = useState([]);
  const [predictionsByTrack, setPredictionsByTrack] = useState({});
  const [resultDistribution, setResultDistribution] = useState({});
  const [chartsLoaded, setChartsLoaded] = useState(false);
  const [isLoadingCharts, setIsLoadingCharts] = useState(false);

  // Load chart.js dynamically only in client
  useEffect(() => {
    async function loadChartLibraries() {
      if (typeof window !== 'undefined' && !chartsLoaded && !isLoadingCharts) {
        try {
          setIsLoadingCharts(true);
          // Dynamic imports
          const chartJsModule = await import('chart.js');
          const reactChartJs2Module = await import('react-chartjs-2');
          
          // Register required components
          chartJsModule.Chart.register(
            chartJsModule.CategoryScale,
            chartJsModule.LinearScale,
            chartJsModule.BarElement,
            chartJsModule.LineElement,
            chartJsModule.PointElement,
            chartJsModule.ArcElement,
            chartJsModule.Title,
            chartJsModule.Tooltip,
            chartJsModule.Legend
          );
          
          Chart = chartJsModule.Chart;
          chartComponents = {
            Bar: reactChartJs2Module.Bar,
            Line: reactChartJs2Module.Line,
            Pie: reactChartJs2Module.Pie
          };
          
          setChartsLoaded(true);
        } catch (error) {
          console.error('Failed to load chart libraries:', error);
        } finally {
          setIsLoadingCharts(false);
        }
      }
    }
    
    loadChartLibraries();
  }, [chartsLoaded, isLoadingCharts]);

  useEffect(() => {
    if (predictions && predictions.length > 0) {
      calculateMonthlyPerformance();
      calculatePredictionsByTrack();
      calculateResultDistribution();
    }
  }, [predictions]);

  const calculateMonthlyPerformance = () => {
    const months = {};
    
    predictions.forEach(prediction => {
      const date = new Date(prediction.date);
      const monthYear = `${date.getMonth() + 1}/${date.getFullYear()}`;
      
      if (!months[monthYear]) {
        months[monthYear] = {
          totalBets: 0,
          wins: 0,
          investment: 0,
          returns: 0
        };
      }
      
      months[monthYear].totalBets += 1;
      months[monthYear].investment += 10; // Assuming $10 bet
      
      if (prediction.result === 'win') {
        months[monthYear].wins += 1;
        months[monthYear].returns += prediction.odds * 10;
      }
    });
    
    const sortedMonths = Object.keys(months).sort((a, b) => {
      const [monthA, yearA] = a.split('/').map(Number);
      const [monthB, yearB] = b.split('/').map(Number);
      
      if (yearA !== yearB) return yearA - yearB;
      return monthA - monthB;
    });
    
    const monthlyData = sortedMonths.map(month => ({
      month,
      totalBets: months[month].totalBets,
      winRate: (months[month].wins / months[month].totalBets) * 100,
      roi: ((months[month].returns - months[month].investment) / months[month].investment) * 100
    }));
    
    setMonthlyPerformance(monthlyData);
  };

  const calculatePredictionsByTrack = () => {
    const tracks = {};
    
    predictions.forEach(prediction => {
      const track = prediction.track;
      
      if (!tracks[track]) {
        tracks[track] = {
          totalBets: 0,
          wins: 0,
          places: 0,
          losses: 0
        };
      }
      
      tracks[track].totalBets += 1;
      
      if (prediction.result === 'win') {
        tracks[track].wins += 1;
      } else if (prediction.result === 'place') {
        tracks[track].places += 1;
      } else if (prediction.result === 'loss') {
        tracks[track].losses += 1;
      }
    });
    
    setPredictionsByTrack(tracks);
  };

  const calculateResultDistribution = () => {
    const results = {
      win: 0,
      place: 0,
      loss: 0,
      pending: 0
    };
    
    predictions.forEach(prediction => {
      if (prediction.result === 'win') {
        results.win += 1;
      } else if (prediction.result === 'place') {
        results.place += 1;
      } else if (prediction.result === 'loss') {
        results.loss += 1;
      } else {
        results.pending += 1;
      }
    });
    
    setResultDistribution(results);
  };

  // Chart data and options (only used when charts are loaded)
  const getMonthlyPerformanceData = () => ({
    labels: monthlyPerformance.map(data => data.month),
    datasets: [
      {
        label: 'Win Rate (%)',
        data: monthlyPerformance.map(data => data.winRate.toFixed(2)),
        backgroundColor: 'rgba(54, 162, 235, 0.5)',
        borderColor: 'rgba(54, 162, 235, 1)',
        borderWidth: 1,
        yAxisID: 'y',
      },
      {
        label: 'ROI (%)',
        data: monthlyPerformance.map(data => data.roi.toFixed(2)),
        backgroundColor: 'rgba(255, 99, 132, 0.5)',
        borderColor: 'rgba(255, 99, 132, 1)',
        borderWidth: 1,
        type: 'line',
        yAxisID: 'y1',
      }
    ]
  });

  const getMonthlyPerformanceOptions = () => ({
    responsive: true,
    interaction: {
      mode: 'index',
      intersect: false,
    },
    scales: {
      y: {
        type: 'linear',
        display: true,
        position: 'left',
        title: {
          display: true,
          text: 'Win Rate (%)'
        }
      },
      y1: {
        type: 'linear',
        display: true,
        position: 'right',
        grid: {
          drawOnChartArea: false,
        },
        title: {
          display: true,
          text: 'ROI (%)'
        }
      },
    },
    plugins: {
      title: {
        display: true,
        text: 'Monthly Performance'
      },
    },
  });

  const getTrackPerformanceData = () => ({
    labels: Object.keys(predictionsByTrack),
    datasets: [
      {
        label: 'Wins',
        data: Object.values(predictionsByTrack).map(track => track.wins),
        backgroundColor: 'rgba(75, 192, 192, 0.5)',
        borderColor: 'rgba(75, 192, 192, 1)',
        borderWidth: 1,
      },
      {
        label: 'Places',
        data: Object.values(predictionsByTrack).map(track => track.places),
        backgroundColor: 'rgba(54, 162, 235, 0.5)',
        borderColor: 'rgba(54, 162, 235, 1)',
        borderWidth: 1,
      },
      {
        label: 'Losses',
        data: Object.values(predictionsByTrack).map(track => track.losses),
        backgroundColor: 'rgba(255, 99, 132, 0.5)',
        borderColor: 'rgba(255, 99, 132, 1)',
        borderWidth: 1,
      }
    ]
  });

  const getTrackPerformanceOptions = () => ({
    responsive: true,
    plugins: {
      legend: {
        position: 'top',
      },
      title: {
        display: true,
        text: 'Performance by Track'
      },
    },
    scales: {
      x: {
        stacked: false,
      },
      y: {
        stacked: false,
        title: {
          display: true,
          text: 'Number of Predictions'
        }
      }
    }
  });

  const getResultDistributionData = () => ({
    labels: ['Win', 'Place', 'Loss', 'Pending'],
    datasets: [
      {
        data: [
          resultDistribution.win || 0,
          resultDistribution.place || 0,
          resultDistribution.loss || 0,
          resultDistribution.pending || 0
        ],
        backgroundColor: [
          'rgba(75, 192, 192, 0.5)',
          'rgba(54, 162, 235, 0.5)',
          'rgba(255, 99, 132, 0.5)',
          'rgba(201, 203, 207, 0.5)'
        ],
        borderColor: [
          'rgba(75, 192, 192, 1)',
          'rgba(54, 162, 235, 1)',
          'rgba(255, 99, 132, 1)',
          'rgba(201, 203, 207, 1)'
        ],
        borderWidth: 1,
      }
    ]
  });

  const getResultDistributionOptions = () => ({
    responsive: true,
    plugins: {
      legend: {
        position: 'right',
      },
      title: {
        display: true,
        text: 'Prediction Results Distribution'
      },
    }
  });

  // Fallback chart component when chart.js is not loaded
  const ChartPlaceholder = ({ title, height = "300px" }) => (
    <div 
      className="flex flex-col items-center justify-center bg-gray-100 rounded-lg p-4"
      style={{ height }}
    >
      <p className="text-gray-500 mb-2">{title}</p>
      <p className="text-sm text-gray-400">Chart visualization loading...</p>
      {isLoadingCharts && <LoadingSpinner size="small" />}
      {!isLoadingCharts && !chartsLoaded && (
        <button 
          className="mt-2 text-sm text-blue-500 hover:text-blue-700"
          onClick={() => setChartsLoaded(false)} // This will trigger the chart loading again
        >
          Load visualization
        </button>
      )}
    </div>
  );

  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Dashboard</h1>
      
      {loading && <div className="text-center py-8">Loading data...</div>}
      
      {error && (
        <div className="bg-red-100 border-l-4 border-red-500 p-4 mb-6">
          <p className="text-red-700">{error}</p>
        </div>
      )}
      
      {!loading && !error && predictions.length === 0 && (
        <div className="text-center py-8">
          <p className="text-gray-500 mb-4">You haven't made any predictions yet.</p>
          <a href="/predict" className="btn btn-primary">
            Make Your First Prediction
          </a>
        </div>
      )}
      
      {!loading && !error && predictions.length > 0 && (
        <div className="space-y-8">
          {/* Performance Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="card bg-blue-50 border border-blue-100">
              <div className="text-center">
                <p className="text-sm text-gray-500 mb-1">Total Predictions</p>
                <p className="text-3xl font-bold text-blue-600">{metrics?.totalPredictions || 0}</p>
              </div>
            </div>
            
            <div className="card bg-green-50 border border-green-100">
              <div className="text-center">
                <p className="text-sm text-gray-500 mb-1">Win Rate</p>
                <p className="text-3xl font-bold text-green-600">{metrics?.successRate.toFixed(2) || 0}%</p>
              </div>
            </div>
            
            <div className="card bg-yellow-50 border border-yellow-100">
              <div className="text-center">
                <p className="text-sm text-gray-500 mb-1">Average Odds</p>
                <p className="text-3xl font-bold text-yellow-600">{metrics?.averageOdds.toFixed(2) || 0}</p>
              </div>
            </div>
            
            <div className="card bg-purple-50 border border-purple-100">
              <div className="text-center">
                <p className="text-sm text-gray-500 mb-1">ROI</p>
                <p className={`text-3xl font-bold ${metrics?.roi >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                  {metrics?.roi.toFixed(2) || 0}%
                </p>
              </div>
            </div>
          </div>
          
          {/* Monthly Performance Chart */}
          <div className="card">
            <h2 className="text-xl font-bold mb-4">Monthly Performance</h2>
            <div className="h-80">
              {chartsLoaded && chartComponents ? (
                <chartComponents.Bar 
                  data={getMonthlyPerformanceData()} 
                  options={getMonthlyPerformanceOptions()} 
                />
              ) : (
                <ChartPlaceholder title="Monthly Performance" height="320px" />
              )}
            </div>
          </div>
          
          {/* Track Performance and Result Distribution */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="card">
              <h2 className="text-xl font-bold mb-4">Performance by Track</h2>
              <div className="h-80">
                {chartsLoaded && chartComponents ? (
                  <chartComponents.Bar 
                    data={getTrackPerformanceData()} 
                    options={getTrackPerformanceOptions()} 
                  />
                ) : (
                  <ChartPlaceholder title="Performance by Track" height="320px" />
                )}
              </div>
            </div>
            
            <div className="card">
              <h2 className="text-xl font-bold mb-4">Result Distribution</h2>
              <div className="h-80">
                {chartsLoaded && chartComponents ? (
                  <chartComponents.Pie 
                    data={getResultDistributionData()} 
                    options={getResultDistributionOptions()} 
                  />
                ) : (
                  <ChartPlaceholder title="Result Distribution" height="320px" />
                )}
              </div>
            </div>
          </div>
          
          {/* Recent Predictions */}
          <div className="card">
            <h2 className="text-xl font-bold mb-4">Recent Predictions</h2>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Date
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Horse
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Predicted
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Actual
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Result
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {predictions.slice(0, 5).map((prediction) => (
                    <tr key={prediction.id}>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {prediction.date}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                        {prediction.horseName}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {prediction.predictedPosition}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {prediction.actualPosition || "-"}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        {prediction.result ? (
                          <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                            ${prediction.result === 'win' ? 'bg-green-100 text-green-800' : 
                              prediction.result === 'place' ? 'bg-blue-100 text-blue-800' : 
                              'bg-red-100 text-red-800'}`}>
                            {prediction.result === 'win' ? 'Win' : 
                             prediction.result === 'place' ? 'Place' : 'Loss'}
                          </span>
                        ) : (
                          <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-gray-100 text-gray-800">
                            Pending
                          </span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="mt-4 text-right">
              <a href="/history" className="text-blue-600 hover:text-blue-800">
                View all predictions →
              </a>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
