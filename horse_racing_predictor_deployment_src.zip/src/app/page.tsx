"use client";

import Link from "next/link";
import Image from "next/image";

export default function HomePage() {
  return (
    <div className="space-y-12">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-600 to-blue-800 text-white rounded-xl p-8 shadow-lg">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            Predict Horse Race Outcomes with Machine Learning
          </h1>
          <p className="text-xl mb-8">
            Make informed betting decisions with our advanced prediction model that achieves over 200% ROI
          </p>
          <Link href="/predict" className="btn bg-white text-blue-700 hover:bg-gray-100 font-bold py-3 px-8 rounded-full text-lg">
            Make a Prediction
          </Link>
        </div>
      </section>

      {/* Features Section */}
      <section>
        <h2 className="text-3xl font-bold text-center mb-8">How It Works</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="card text-center">
            <div className="bg-blue-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
            </div>
            <h3 className="text-xl font-semibold mb-2">Enter Race Data</h3>
            <p className="text-gray-600">
              Input details about the race, horses, jockeys, and track conditions
            </p>
          </div>
          
          <div className="card text-center">
            <div className="bg-blue-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" />
              </svg>
            </div>
            <h3 className="text-xl font-semibold mb-2">AI Analysis</h3>
            <p className="text-gray-600">
              Our machine learning model analyzes the data using patterns from thousands of races
            </p>
          </div>
          
          <div className="card text-center">
            <div className="bg-blue-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <h3 className="text-xl font-semibold mb-2">Get Predictions</h3>
            <p className="text-gray-600">
              Receive predicted finishing order and betting recommendations with expected ROI
            </p>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="bg-gray-100 rounded-xl p-8">
        <h2 className="text-3xl font-bold text-center mb-8">Proven Performance</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
          <div>
            <p className="text-4xl font-bold text-blue-600">64%</p>
            <p className="text-xl">Top-3 Accuracy</p>
          </div>
          <div>
            <p className="text-4xl font-bold text-blue-600">221%</p>
            <p className="text-xl">Return on Investment</p>
          </div>
          <div>
            <p className="text-4xl font-bold text-blue-600">3,000+</p>
            <p className="text-xl">Races Analyzed</p>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="text-center">
        <h2 className="text-3xl font-bold mb-4">Ready to make smarter bets?</h2>
        <p className="text-xl mb-8 max-w-2xl mx-auto">
          Start using our prediction model today and transform your approach to horse race betting
        </p>
        <Link href="/predict" className="btn btn-primary py-3 px-8 text-lg">
          Get Started Now
        </Link>
      </section>
    </div>
  );
}
