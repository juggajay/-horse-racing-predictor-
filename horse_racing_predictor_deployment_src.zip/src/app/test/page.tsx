"use client";

import { useState, useEffect } from 'react';
import { usePredictions } from '@/hooks/usePredictions';
import { validatePredictionInput } from '@/lib/test-utils';
import { PredictionInput } from '@/lib/types';

export default function TestPage() {
  const [testStatus, setTestStatus] = useState<'idle' | 'running' | 'success' | 'failed'>('idle');
  const [testResults, setTestResults] = useState<any>(null);
  const [apiTestStatus, setApiTestStatus] = useState<'idle' | 'running' | 'success' | 'failed'>('idle');
  const [apiTestResults, setApiTestResults] = useState<any>(null);
  const { createPrediction, fetchPredictions, updatePredictionResult, deletePrediction } = usePredictions();

  const runValidationTests = () => {
    setTestStatus('running');
    
    try {
      // Test case 1: Valid input
      const validInput: PredictionInput = {
        race: {
          track: 'track1',
          race_class: 'BM70',
          distance: 1400,
          track_condition: 'Good4',
          race_date: '2025-03-20'
        },
        horse: {
          horse_name: 'Test Horse',
          barrier: 4,
          weight: 56.5,
          previous_weight: 57.0,
          days_since_last_race: 14,
          career_wins: 3,
          career_runs: 12,
          last_5_positions: '3,5,2,4,1'
        },
        jockeyTrainer: {
          jockey_name: 'Test Jockey',
          trainer_name: 'Test Trainer',
          jockey_wins: 120,
          jockey_runs: 500,
          trainer_wins: 85,
          trainer_runs: 340,
          sp_odds: 5.5
        }
      };
      
      // Test case 2: Invalid input - missing required fields
      const invalidInput1: any = {
        race: {
          track: '',
          race_class: 'BM70',
          distance: 1400,
          track_condition: 'Good4',
          race_date: '2025-03-20'
        },
        horse: {
          horse_name: '',
          barrier: 4,
          weight: 56.5,
          previous_weight: 57.0,
          days_since_last_race: 14,
          career_wins: 3,
          career_runs: 12,
          last_5_positions: '3,5,2,4,1'
        },
        jockeyTrainer: {
          jockey_name: 'Test Jockey',
          trainer_name: 'Test Trainer',
          jockey_wins: 120,
          jockey_runs: 500,
          trainer_wins: 85,
          trainer_runs: 340,
          sp_odds: 5.5
        }
      };
      
      // Test case 3: Invalid input - logical errors
      const invalidInput2: PredictionInput = {
        race: {
          track: 'track1',
          race_class: 'BM70',
          distance: 1800, // Outside valid range
          track_condition: 'Good4',
          race_date: '2025-03-20'
        },
        horse: {
          horse_name: 'Test Horse',
          barrier: 4,
          weight: 56.5,
          previous_weight: 57.0,
          days_since_last_race: 14,
          career_wins: 15, // More wins than runs
          career_runs: 12,
          last_5_positions: '3,5,2,4,1'
        },
        jockeyTrainer: {
          jockey_name: 'Test Jockey',
          trainer_name: 'Test Trainer',
          jockey_wins: 120,
          jockey_runs: 500,
          trainer_wins: 85,
          trainer_runs: 340,
          sp_odds: 0.5 // Invalid odds
        }
      };
      
      const validationResult1 = validatePredictionInput(validInput);
      const validationResult2 = validatePredictionInput(invalidInput1);
      const validationResult3 = validatePredictionInput(invalidInput2);
      
      const results = {
        testCase1: {
          input: validInput,
          validation: validationResult1,
          passed: validationResult1.isValid === true
        },
        testCase2: {
          input: invalidInput1,
          validation: validationResult2,
          passed: validationResult2.isValid === false && validationResult2.errors.length > 0
        },
        testCase3: {
          input: invalidInput2,
          validation: validationResult3,
          passed: validationResult3.isValid === false && validationResult3.errors.length > 0
        },
        summary: {
          totalTests: 3,
          passedTests: [
            validationResult1.isValid === true,
            validationResult2.isValid === false && validationResult2.errors.length > 0,
            validationResult3.isValid === false && validationResult3.errors.length > 0
          ].filter(Boolean).length
        }
      };
      
      setTestResults(results);
      setTestStatus(results.summary.totalTests === results.summary.passedTests ? 'success' : 'failed');
    } catch (error) {
      console.error('Validation test error:', error);
      setTestStatus('failed');
      setTestResults({ error: 'Test execution failed' });
    }
  };

  const runApiTests = async () => {
    setApiTestStatus('running');
    
    try {
      // Test the test API endpoint
      const testApiResponse = await fetch('/api/test');
      const testApiData = await testApiResponse.json();
      
      // Test creating a prediction
      let createdPrediction = null;
      let createError = null;
      try {
        const sampleInput = testApiData.data.sampleInput;
        createdPrediction = await createPrediction(sampleInput);
      } catch (error) {
        console.error('Error creating prediction:', error);
        createError = error;
      }
      
      // Test fetching predictions
      let fetchedPredictions = null;
      let fetchError = null;
      try {
        await fetchPredictions();
        // We don't have direct access to the fetched predictions here,
        // but the function call should not throw an error
        fetchedPredictions = { status: 'Fetch function called successfully' };
      } catch (error) {
        console.error('Error fetching predictions:', error);
        fetchError = error;
      }
      
      // Test updating a prediction (if one was created)
      let updatedPrediction = null;
      let updateError = null;
      if (createdPrediction) {
        try {
          updatedPrediction = await updatePredictionResult(createdPrediction.id, 1);
        } catch (error) {
          console.error('Error updating prediction:', error);
          updateError = error;
        }
      }
      
      // Test deleting a prediction (if one was created and updated)
      let deleteResult = null;
      let deleteError = null;
      if (updatedPrediction) {
        try {
          deleteResult = await deletePrediction(updatedPrediction.id);
        } catch (error) {
          console.error('Error deleting prediction:', error);
          deleteError = error;
        }
      }
      
      const results = {
        testApiEndpoint: {
          status: testApiData.success ? 'success' : 'failed',
          data: testApiData.data,
          passed: testApiData.success && testApiData.data.predictionResult !== null
        },
        createPrediction: {
          status: createdPrediction ? 'success' : 'failed',
          data: createdPrediction,
          error: createError,
          passed: createdPrediction !== null
        },
        fetchPredictions: {
          status: fetchedPredictions ? 'success' : 'failed',
          data: fetchedPredictions,
          error: fetchError,
          passed: fetchedPredictions !== null
        },
        updatePrediction: {
          status: updatedPrediction ? 'success' : 'failed',
          data: updatedPrediction,
          error: updateError,
          passed: updatedPrediction !== null
        },
        deletePrediction: {
          status: deleteResult ? 'success' : 'failed',
          data: deleteResult,
          error: deleteError,
          passed: deleteResult !== null
        },
        summary: {
          totalTests: 5,
          passedTests: [
            testApiData.success && testApiData.data.predictionResult !== null,
            createdPrediction !== null,
            fetchedPredictions !== null,
            updatedPrediction !== null,
            deleteResult !== null
          ].filter(Boolean).length
        }
      };
      
      setApiTestResults(results);
      setApiTestStatus(results.summary.passedTests === results.summary.totalTests ? 'success' : 'failed');
    } catch (error) {
      console.error('API test error:', error);
      setApiTestStatus('failed');
      setApiTestResults({ error: 'Test execution failed' });
    }
  };

  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Website Testing</h1>
      
      <div className="space-y-8">
        {/* Input Validation Tests */}
        <div className="card">
          <h2 className="text-2xl font-bold mb-4">Input Validation Tests</h2>
          <p className="mb-4">
            These tests verify that the input validation logic correctly identifies valid and invalid prediction inputs.
          </p>
          
          <div className="mb-4">
            <button 
              className={`btn ${testStatus === 'idle' || testStatus === 'failed' ? 'btn-primary' : 'bg-gray-400'}`}
              onClick={runValidationTests}
              disabled={testStatus === 'running'}
            >
              {testStatus === 'running' ? 'Running Tests...' : 'Run Validation Tests'}
            </button>
          </div>
          
          {testStatus !== 'idle' && (
            <div className={`p-4 rounded-md ${
              testStatus === 'running' ? 'bg-blue-50 border border-blue-200' :
              testStatus === 'success' ? 'bg-green-50 border border-green-200' :
              'bg-red-50 border border-red-200'
            }`}>
              <div className="flex items-center mb-2">
                <div className={`w-4 h-4 rounded-full mr-2 ${
                  testStatus === 'running' ? 'bg-blue-500' :
                  testStatus === 'success' ? 'bg-green-500' :
                  'bg-red-500'
                }`}></div>
                <p className="font-medium">
                  {testStatus === 'running' ? 'Tests in progress...' :
                   testStatus === 'success' ? 'All tests passed!' :
                   'Some tests failed'}
                </p>
              </div>
              
              {testResults && testStatus !== 'running' && (
                <div className="mt-4">
                  <p className="font-medium">Summary: {testResults.summary.passedTests}/{testResults.summary.totalTests} tests passed</p>
                  
                  <div className="mt-2 space-y-4">
                    <div className={`p-3 rounded ${testResults.testCase1.passed ? 'bg-green-100' : 'bg-red-100'}`}>
                      <p className="font-medium">Test Case 1: Valid Input</p>
                      <p>Result: {testResults.testCase1.passed ? 'Passed' : 'Failed'}</p>
                      {!testResults.testCase1.passed && (
                        <div className="mt-2">
                          <p>Validation Errors:</p>
                          <ul className="list-disc pl-5">
                            {testResults.testCase1.validation.errors.map((error, index) => (
                              <li key={index}>{error}</li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </div>
                    
                    <div className={`p-3 rounded ${testResults.testCase2.passed ? 'bg-green-100' : 'bg-red-100'}`}>
                      <p className="font-medium">Test Case 2: Missing Required Fields</p>
                      <p>Result: {testResults.testCase2.passed ? 'Passed' : 'Failed'}</p>
                      {testResults.testCase2.passed && (
                        <div className="mt-2">
                          <p>Validation Errors (expected):</p>
                          <ul className="list-disc pl-5">
                            {testResults.testCase2.validation.errors.map((error, index) => (
                              <li key={index}>{error}</li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </div>
                    
                    <div className={`p-3 rounded ${testResults.testCase3.passed ? 'bg-green-100' : 'bg-red-100'}`}>
                      <p className="font-medium">Test Case 3: Logical Errors</p>
                      <p>Result: {testResults.testCase3.passed ? 'Passed' : 'Failed'}</p>
                      {testResults.testCase3.passed && (
                        <div className="mt-2">
                          <p>Validation Errors (expected):</p>
                          <ul className="list-disc pl-5">
                            {testResults.testCase3.validation.errors.map((error, index) => (
                              <li key={index}>{error}</li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
        
        {/* API Tests */}
        <div className="card">
          <h2 className="text-2xl font-bold mb-4">API Integration Tests</h2>
          <p className="mb-4">
            These tests verify that the API endpoints and data processing functions work correctly.
          </p>
          
          <div className="mb-4">
            <button 
              className={`btn ${apiTestStatus === 'idle' || apiTestStatus === 'failed' ? 'btn-primary' : 'bg-gray-400'}`}
              onClick={runApiTests}
              disabled={apiTestStatus === 'running'}
            >
              {apiTestStatus === 'running' ? 'Running Tests...' : 'Run API Tests'}
            </button>
          </div>
          
          {apiTestStatus !== 'idle' && (
            <div className={`p-4 rounded-md ${
              apiTestStatus === 'running' ? 'bg-blue-50 border border-blue-200' :
              apiTestStatus === 'success' ? 'bg-green-50 border border-green-200' :
              'bg-red-50 border border-red-200'
            }`}>
              <div className="flex items-center mb-2">
                <div className={`w-4 h-4 rounded-full mr-2 ${
                  apiTestStatus === 'running' ? 'bg-blue-500' :
                  apiTestStatus === 'success' ? 'bg-green-500' :
                  'bg-red-500'
                }`}></div>
                <p className="font-medium">
                  {apiTestStatus === 'running' ? 'Tests in progress...' :
                   apiTestStatus === 'success' ? 'All tests passed!' :
                   'Some tests failed'}
                </p>
              </div>
              
              {apiTestResults && apiTestStatus !== 'running' && (
                <div className="mt-4">
                  <p className="font-medium">Summary: {apiTestResults.summary.passedTests}/{apiTestResults.summary.totalTests} tests passed</p>
                  
                  <div className="mt-2 space-y-4">
                    <div className={`p-3 rounded ${apiTestResults.testApiEndpoint.passed ? 'bg-green-100' : 'bg-red-100'}`}>
                      <p className="font-medium">Test API Endpoint</p>
                      <p>Status: {apiTestResults.testApiEndpoint.status}</p>
                      <p>Result: {apiTestResults.testApiEndpoint.passed ? 'Passed' : 'Failed'}</p>
                    </div>
                    
                    <div className={`p-3 rounded ${apiTestResults.createPrediction.passed ? 'bg-green-100' : 'bg-red-100'}`}>
                      <p className="font-medium">Create Prediction</p>
                      <p>Status: {apiTestResults.createPrediction.status}</p>
                      <p>Result: {apiTestResults.createPrediction.passed ? 'Passed' : 'Failed'}</p>
                      {apiTestResults.createPrediction.error && (
                        <p className="text-red-600">Error: {apiTestResults.createPrediction.error.toString()}</p>
                      )}
                    </div>
                    
                    <div className={`p-3 rounded ${apiTestResults.fetchPredictions.passed ? 'bg-green-100' : 'bg-red-100'}`}>
                      <p className="font-medium">Fetch Predictions</p>
                      <p>Status: {apiTestResults.fetchPredictions.status}</p>
                      <p>Result: {apiTestResults.fetchPredictions.passed ? 'Passed' : 'Failed'}</p>
                      {apiTestResults.fetchPredictions.error && (
                        <p className="text-red-600">Error: {apiTestResults.fetchPredictions.error.toString()}</p>
                      )}
                    </div>
                    
                    <div className={`p-3 rounded ${apiTestResults.updatePrediction.passed ? 'bg-green-100' : 'bg-red-100'}`}>
                      <p className="font-medium">Update Prediction</p>
                      <p>Status: {apiTestResults.updatePrediction.status}</p>
                      <p>Result: {apiTestResults.updatePrediction.passed ? 'Passed' : 'Failed'}</p>
                      {apiTestResults.updatePrediction.error && (
                        <p className="text-red-600">Error: {apiTestResults.updatePrediction.error.toString()}</p>
                      )}
                    </div>
                    
                    <div className={`p-3 rounded ${apiTestResults.deletePrediction.passed ? 'bg-green-100' : 'bg-red-100'}`}>
                      <p className="font-medium">Delete Prediction</p>
                      <p>Status: {apiTestResults.deletePrediction.status}</p>
                      <p>Result: {apiTestResults.deletePrediction.passed ? 'Passed' : 'Failed'}</p>
                      {apiTestResults.deletePrediction.error && (
                        <p className="text-red-600">Error: {apiTestResults.deletePrediction.error.toString()}</p>
                      )}
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
