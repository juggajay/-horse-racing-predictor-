"use client";

import { useState } from "react";
import Link from "next/link";

export default function AboutPage() {
  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold mb-6">About Horse Racing Predictor</h1>
      
      <div className="card">
        <h2 className="text-2xl font-bold mb-4">Our Technology</h2>
        <p className="mb-4">
          Horse Racing Predictor uses advanced machine learning algorithms to analyze historical race data and predict the outcomes of future races. Our system is built on a Random Forest Regressor model that has been trained on data from over 3,000 Australian handicap (Benchmark - BM) races.
        </p>
        <p className="mb-4">
          The model takes into account a wide range of factors including:
        </p>
        <ul className="list-disc pl-8 mb-4 space-y-2">
          <li>Horse's past performance and form</li>
          <li>Jockey and trainer statistics</li>
          <li>Track conditions and race distance</li>
          <li>Weight carried and barrier position</li>
          <li>Days since last race and weight changes</li>
        </ul>
        <p>
          Our prediction system has demonstrated a Top-3 Accuracy of 64.05%, meaning it correctly identifies the winner within its top 3 predictions about 64% of the time. When used with our recommended betting strategies, it has achieved a Return on Investment (ROI) of over 200% in backtesting.
        </p>
      </div>
      
      <div className="card">
        <h2 className="text-2xl font-bold mb-4">How to Use the Predictor</h2>
        <ol className="list-decimal pl-8 mb-4 space-y-4">
          <li>
            <p className="font-semibold">Enter Race Details</p>
            <p className="text-gray-600">Provide information about the race including track, class, distance, and track condition.</p>
          </li>
          <li>
            <p className="font-semibold">Input Horse Information</p>
            <p className="text-gray-600">Enter details about the horse including name, barrier, weight, and past performance.</p>
          </li>
          <li>
            <p className="font-semibold">Add Jockey and Trainer Data</p>
            <p className="text-gray-600">Include information about the jockey and trainer, such as their names and career statistics.</p>
          </li>
          <li>
            <p className="font-semibold">Generate Prediction</p>
            <p className="text-gray-600">Our model will analyze the data and provide a predicted finishing position along with betting recommendations.</p>
          </li>
          <li>
            <p className="font-semibold">Track Results</p>
            <p className="text-gray-600">Save your predictions and track their accuracy over time to measure your success.</p>
          </li>
        </ol>
        <div className="mt-4">
          <Link href="/predict" className="btn btn-primary">
            Make a Prediction Now
          </Link>
        </div>
      </div>
      
      <div className="card">
        <h2 className="text-2xl font-bold mb-4">Responsible Gambling</h2>
        <p className="mb-4">
          While our prediction model has shown promising results in backtesting, we emphasize that horse racing betting involves risk and there are no guarantees of profit. We encourage responsible gambling practices:
        </p>
        <ul className="list-disc pl-8 mb-4 space-y-2">
          <li>Only bet what you can afford to lose</li>
          <li>Set a budget and stick to it</li>
          <li>Don't chase losses</li>
          <li>Be aware of the signs of problem gambling</li>
          <li>Seek help if gambling is negatively affecting your life</li>
        </ul>
        <p className="text-sm text-gray-500 italic">
          This tool is for educational purposes only. Always gamble responsibly and adhere to local laws and regulations.
        </p>
      </div>
      
      <div className="card">
        <h2 className="text-2xl font-bold mb-4">Frequently Asked Questions</h2>
        <div className="space-y-4">
          <div>
            <h3 className="text-lg font-semibold">How accurate is the prediction model?</h3>
            <p className="text-gray-600">
              Our model has a Top-3 Accuracy of 64.05%, meaning it correctly identifies the winner within its top 3 predictions about 64% of the time.
            </p>
          </div>
          <div>
            <h3 className="text-lg font-semibold">What betting strategy do you recommend?</h3>
            <p className="text-gray-600">
              Our backtesting shows that betting on the top-ranked horse (Top-1 strategy) has achieved the highest ROI of 221.03%. However, individual results may vary.
            </p>
          </div>
          <div>
            <h3 className="text-lg font-semibold">Can I use this for any horse race?</h3>
            <p className="text-gray-600">
              The model is specifically trained on Australian handicap (Benchmark - BM) races with distances between 1200m and 1600m. It may not perform as well for other types of races.
            </p>
          </div>
          <div>
            <h3 className="text-lg font-semibold">How often is the model updated?</h3>
            <p className="text-gray-600">
              We regularly update our model with new race data to ensure it remains accurate and up-to-date with current racing trends.
            </p>
          </div>
          <div>
            <h3 className="text-lg font-semibold">Is there a limit to how many predictions I can make?</h3>
            <p className="text-gray-600">
              No, you can make as many predictions as you like. We encourage you to save your predictions and track their accuracy over time.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
