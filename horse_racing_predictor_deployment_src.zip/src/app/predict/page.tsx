"use client";

import { useState } from "react";
import Link from "next/link";
import { usePredictions } from "@/hooks/usePredictions";
import { PredictionInput, PredictionResult, SavedPrediction } from "@/lib/types";

export default function PredictPage() {
  const [formStep, setFormStep] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const [predictionResult, setPredictionResult] = useState<SavedPrediction | null>(null);
  const { createPrediction } = usePredictions();

  // Form state
  const [raceData, setRaceData] = useState({
    track: "",
    race_class: "",
    distance: "",
    track_condition: "",
    race_date: ""
  });

  const [horseData, setHorseData] = useState({
    horse_name: "",
    barrier: "",
    weight: "",
    previous_weight: "",
    days_since_last_race: "",
    career_wins: "",
    career_runs: "",
    last_5_positions: ""
  });

  const [jockeyTrainerData, setJockeyTrainerData] = useState({
    jockey_name: "",
    trainer_name: "",
    jockey_wins: "",
    jockey_runs: "",
    trainer_wins: "",
    trainer_runs: "",
    sp_odds: ""
  });

  const nextStep = () => {
    setFormStep(formStep + 1);
    window.scrollTo(0, 0);
  };

  const prevStep = () => {
    setFormStep(formStep - 1);
    window.scrollTo(0, 0);
  };

  const handleRaceDataChange = (e) => {
    const { id, value } = e.target;
    setRaceData(prev => ({ ...prev, [id]: value }));
  };

  const handleHorseDataChange = (e) => {
    const { id, value } = e.target;
    setHorseData(prev => ({ ...prev, [id]: value }));
  };

  const handleJockeyTrainerDataChange = (e) => {
    const { id, value } = e.target;
    setJockeyTrainerData(prev => ({ ...prev, [id]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    
    // Prepare input data
    const input: PredictionInput = {
      race: {
        track: raceData.track,
        race_class: raceData.race_class,
        distance: Number(raceData.distance),
        track_condition: raceData.track_condition,
        race_date: raceData.race_date
      },
      horse: {
        horse_name: horseData.horse_name,
        barrier: Number(horseData.barrier),
        weight: Number(horseData.weight),
        previous_weight: Number(horseData.previous_weight),
        days_since_last_race: Number(horseData.days_since_last_race),
        career_wins: Number(horseData.career_wins),
        career_runs: Number(horseData.career_runs),
        last_5_positions: horseData.last_5_positions
      },
      jockeyTrainer: {
        jockey_name: jockeyTrainerData.jockey_name,
        trainer_name: jockeyTrainerData.trainer_name,
        jockey_wins: Number(jockeyTrainerData.jockey_wins),
        jockey_runs: Number(jockeyTrainerData.jockey_runs),
        trainer_wins: Number(jockeyTrainerData.trainer_wins),
        trainer_runs: Number(jockeyTrainerData.trainer_runs),
        sp_odds: Number(jockeyTrainerData.sp_odds)
      }
    };
    
    try {
      // Call API to create prediction
      const result = await createPrediction(input);
      
      if (result) {
        setPredictionResult(result);
        setFormStep(4); // Move to results step
      }
    } catch (error) {
      console.error("Error creating prediction:", error);
      alert("Failed to generate prediction. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Make a Prediction</h1>
      
      {/* Progress Bar */}
      <div className="mb-8">
        <div className="flex justify-between mb-2">
          <span className={`font-medium ${formStep >= 1 ? 'text-blue-600' : 'text-gray-400'}`}>Race Details</span>
          <span className={`font-medium ${formStep >= 2 ? 'text-blue-600' : 'text-gray-400'}`}>Horse Information</span>
          <span className={`font-medium ${formStep >= 3 ? 'text-blue-600' : 'text-gray-400'}`}>Jockey & Trainer</span>
          <span className={`font-medium ${formStep >= 4 ? 'text-blue-600' : 'text-gray-400'}`}>Results</span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2.5">
          <div 
            className="bg-blue-600 h-2.5 rounded-full transition-all duration-300" 
            style={{ width: `${(formStep / 4) * 100}%` }}
          ></div>
        </div>
      </div>

      {/* Form Steps */}
      <div className="card">
        {formStep === 1 && (
          <div>
            <h2 className="text-2xl font-bold mb-4">Race Details</h2>
            <form>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="form-group">
                  <label htmlFor="track" className="form-label">Track</label>
                  <select 
                    id="track" 
                    className="form-select"
                    value={raceData.track}
                    onChange={handleRaceDataChange}
                    required
                  >
                    <option value="">Select track</option>
                    <option value="track1">Track 1</option>
                    <option value="track2">Track 2</option>
                    <option value="track3">Track 3</option>
                  </select>
                </div>
                
                <div className="form-group">
                  <label htmlFor="race_class" className="form-label">Race Class</label>
                  <select 
                    id="race_class" 
                    className="form-select"
                    value={raceData.race_class}
                    onChange={handleRaceDataChange}
                    required
                  >
                    <option value="">Select class</option>
                    <option value="BM58">BM58</option>
                    <option value="BM64">BM64</option>
                    <option value="BM70">BM70</option>
                    <option value="BM76">BM76</option>
                    <option value="BM82">BM82</option>
                  </select>
                </div>
                
                <div className="form-group">
                  <label htmlFor="distance" className="form-label">Distance (meters)</label>
                  <input 
                    type="number" 
                    id="distance" 
                    className="form-input" 
                    min="1200" 
                    max="1600" 
                    placeholder="e.g., 1400"
                    value={raceData.distance}
                    onChange={handleRaceDataChange}
                    required
                  />
                </div>
                
                <div className="form-group">
                  <label htmlFor="track_condition" className="form-label">Track Condition</label>
                  <select 
                    id="track_condition" 
                    className="form-select"
                    value={raceData.track_condition}
                    onChange={handleRaceDataChange}
                    required
                  >
                    <option value="">Select condition</option>
                    <option value="Good3">Good3</option>
                    <option value="Good4">Good4</option>
                    <option value="Soft5">Soft5</option>
                    <option value="Soft6">Soft6</option>
                    <option value="Soft7">Soft7</option>
                    <option value="Heavy8">Heavy8</option>
                    <option value="Heavy9">Heavy9</option>
                    <option value="Heavy10">Heavy10</option>
                  </select>
                </div>
                
                <div className="form-group">
                  <label htmlFor="race_date" className="form-label">Race Date</label>
                  <input 
                    type="date" 
                    id="race_date" 
                    className="form-input"
                    value={raceData.race_date}
                    onChange={handleRaceDataChange}
                    required
                  />
                </div>
              </div>
              
              <div className="mt-6 flex justify-end">
                <button 
                  type="button" 
                  onClick={nextStep}
                  className="btn btn-primary"
                >
                  Next: Horse Information
                </button>
              </div>
            </form>
          </div>
        )}

        {formStep === 2 && (
          <div>
            <h2 className="text-2xl font-bold mb-4">Horse Information</h2>
            <form>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="form-group">
                  <label htmlFor="horse_name" className="form-label">Horse Name</label>
                  <input 
                    type="text" 
                    id="horse_name" 
                    className="form-input" 
                    placeholder="Enter horse name"
                    value={horseData.horse_name}
                    onChange={handleHorseDataChange}
                    required
                  />
                </div>
                
                <div className="form-group">
                  <label htmlFor="barrier" className="form-label">Barrier</label>
                  <input 
                    type="number" 
                    id="barrier" 
                    className="form-input" 
                    min="1" 
                    max="20" 
                    placeholder="Barrier number"
                    value={horseData.barrier}
                    onChange={handleHorseDataChange}
                    required
                  />
                </div>
                
                <div className="form-group">
                  <label htmlFor="weight" className="form-label">Weight (kg)</label>
                  <input 
                    type="number" 
                    id="weight" 
                    className="form-input" 
                    step="0.1" 
                    placeholder="e.g., 56.5"
                    value={horseData.weight}
                    onChange={handleHorseDataChange}
                    required
                  />
                </div>
                
                <div className="form-group">
                  <label htmlFor="previous_weight" className="form-label">Previous Race Weight (kg)</label>
                  <input 
                    type="number" 
                    id="previous_weight" 
                    className="form-input" 
                    step="0.1" 
                    placeholder="e.g., 56.0"
                    value={horseData.previous_weight}
                    onChange={handleHorseDataChange}
                    required
                  />
                </div>
                
                <div className="form-group">
                  <label htmlFor="days_since_last_race" className="form-label">Days Since Last Race</label>
                  <input 
                    type="number" 
                    id="days_since_last_race" 
                    className="form-input" 
                    min="0" 
                    placeholder="e.g., 14"
                    value={horseData.days_since_last_race}
                    onChange={handleHorseDataChange}
                    required
                  />
                </div>
                
                <div className="form-group">
                  <label htmlFor="career_wins" className="form-label">Career Wins</label>
                  <input 
                    type="number" 
                    id="career_wins" 
                    className="form-input" 
                    min="0" 
                    placeholder="Number of career wins"
                    value={horseData.career_wins}
                    onChange={handleHorseDataChange}
                    required
                  />
                </div>
                
                <div className="form-group">
                  <label htmlFor="career_runs" className="form-label">Career Runs</label>
                  <input 
                    type="number" 
                    id="career_runs" 
                    className="form-input" 
                    min="0" 
                    placeholder="Number of career runs"
                    value={horseData.career_runs}
                    onChange={handleHorseDataChange}
                    required
                  />
                </div>
                
                <div className="form-group">
                  <label htmlFor="last_5_positions" className="form-label">Last 5 Finishing Positions</label>
                  <input 
                    type="text" 
                    id="last_5_positions" 
                    className="form-input" 
                    placeholder="e.g., 3,1,5,2,7"
                    value={horseData.last_5_positions}
                    onChange={handleHorseDataChange}
                    required
                  />
                </div>
              </div>
              
              <div className="mt-6 flex justify-between">
                <button 
                  type="button" 
                  onClick={prevStep}
                  className="btn bg-gray-300 hover:bg-gray-400 text-gray-800"
                >
                  Back
                </button>
                <button 
                  type="button" 
                  onClick={nextStep}
                  className="btn btn-primary"
                >
                  Next: Jockey & Trainer
                </button>
              </div>
            </form>
          </div>
        )}

        {formStep === 3 && (
          <div>
            <h2 className="text-2xl font-bold mb-4">Jockey & Trainer Information</h2>
            <form onSubmit={handleSubmit}>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="form-group">
                  <label htmlFor="jockey_name" className="form-label">Jockey Name</label>
                  <input 
                    type="text" 
                    id="jockey_name" 
                    className="form-input" 
                    placeholder="Enter jockey name"
                    value={jockeyTrainerData.jockey_name}
                    onChange={handleJockeyTrainerDataChange}
                    required
                  />
                </div>
                
                <div className="form-group">
                  <label htmlFor="trainer_name" className="form-label">Trainer Name</label>
                  <input 
                    type="text" 
                    id="trainer_name" 
                    className="form-input" 
                    placeholder="Enter trainer name"
                    value={jockeyTrainerData.trainer_name}
                    onChange={handleJockeyTrainerDataChange}
                    required
                  />
                </div>
                
                <div className="form-group">
                  <label htmlFor="jockey_wins" className="form-label">Jockey Career Wins</label>
                  <input 
                    type="number" 
                    id="jockey_wins" 
                    className="form-input" 
                    min="0" 
                    placeholder="Number of career wins"
                    value={jockeyTrainerData.jockey_wins}
                    onChange={handleJockeyTrainerDataChange}
                    required
                  />
                </div>
                
                <div className="form-group">
                  <label htmlFor="jockey_runs" className="form-label">Jockey Career Runs</label>
                  <input 
                    type="number" 
                    id="jockey_runs" 
                    className="form-input" 
                    min="0" 
                    placeholder="Number of career runs"
                    value={jockeyTrainerData.jockey_runs}
                    onChange={handleJockeyTrainerDataChange}
                    required
                  />
                </div>
                
                <div className="form-group">
                  <label htmlFor="trainer_wins" className="form-label">Trainer Career Wins</label>
                  <input 
                    type="number" 
                    id="trainer_wins" 
                    className="form-input" 
                    min="0" 
                    placeholder="Number of career wins"
                    value={jockeyTrainerData.trainer_wins}
                    onChange={handleJockeyTrainerDataChange}
                    required
                  />
                </div>
                
                <div className="form-group">
                  <label htmlFor="trainer_runs" className="form-label">Trainer Career Runs</label>
                  <input 
                    type="number" 
                    id="trainer_runs" 
                    className="form-input" 
                    min="0" 
                    placeholder="Number of career runs"
                    value={jockeyTrainerData.trainer_runs}
                    onChange={handleJockeyTrainerDataChange}
                    required
                  />
                </div>
                
                <div className="form-group">
                  <label htmlFor="sp_odds" className="form-label">Starting Price Odds</label>
                  <input 
                    type="number" 
                    id="sp_odds" 
                    className="form-input" 
                    step="0.01" 
                    min="1" 
                    placeholder="e.g., 5.50"
                    value={jockeyTrainerData.sp_odds}
                    onChange={handleJockeyTrainerDataChange}
                    required
                  />
                </div>
              </div>
              
              <div className="mt-6 flex justify-between">
                <button 
                  type="button" 
                  onClick={prevStep}
                  className="btn bg-gray-300 hover:bg-gray-400 text-gray-800"
                >
                  Back
                </button>
                <button 
                  type="submit"
                  className="btn btn-primary"
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <span className="flex items-center">
                      <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      Processing...
                    </span>
                  ) : "Generate Prediction"}
                </button>
              </div>
            </form>
          </div>
        )}

        {formStep === 4 && predictionResult && (
          <div>
            <div className="bg-green-100 border-l-4 border-green-500 p-4 mb-6">
              <p className="text-green-700 font-medium">Prediction generated successfully!</p>
            </div>
            
            <h2 className="text-2xl font-bold mb-4">Prediction Results</h2>
            
            <div className="mb-6">
              <h3 className="text-xl font-semibold mb-2">Predicted Finishing Position</h3>
              <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                <p className="text-4xl font-bold text-blue-600 text-center">
                  {predictionResult.predictedPosition === 1 ? "1st" : 
                   predictionResult.predictedPosition === 2 ? "2nd" : 
                   predictionResult.predictedPosition === 3 ? "3rd" : 
                   `${predictionResult.predictedPosition}th`} Place
                </p>
                <p className="text-center text-gray-600 mt-2">
                  with {predictionResult.output.confidence}% confidence
                </p>
              </div>
            </div>
            
            <div className="mb-6">
              <h3 className="text-xl font-semibold mb-2">Betting Recommendation</h3>
              <div className="bg-green-50 p-4 rounded-lg border border-green-200">
                <p className="font-medium text-green-800">
                  <span className="font-bold">{predictionResult.output.recommendedBet} Bet Recommended</span> - 
                  Expected ROI: {predictionResult.output.expectedROI}%
                </p>
                <p className="text-gray-600 mt-2">
                  Based on the predicted finishing position and current odds, 
                  a {predictionResult.output.recommendedBet.toLowerCase()} bet offers positive expected value.
                </p>
              </div>
            </div>
            
            <div className="mb-6">
              <h3 className="text-xl font-semibold mb-2">Key Factors</h3>
              <ul className="list-disc pl-5 space-y-1">
                {predictionResult.output.keyFactors.map((factor, index) => (
                  <li key={index}>{factor}</li>
                ))}
              </ul>
            </div>
            
            <div className="mt-8 flex justify-between">
              <Link href="/predict" className="btn bg-gray-300 hover:bg-gray-400 text-gray-800">
                New Prediction
              </Link>
              <Link href="/history" className="btn btn-primary">
                View History
              </Link>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
