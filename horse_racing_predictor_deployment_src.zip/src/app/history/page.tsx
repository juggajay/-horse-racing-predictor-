"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { usePredictions } from "@/hooks/usePredictions";

export default function HistoryPage() {
  const { 
    predictions, 
    metrics, 
    loading, 
    error, 
    fetchPredictions, 
    updatePredictionResult, 
    deletePrediction 
  } = usePredictions();
  
  const [selectedPrediction, setSelectedPrediction] = useState(null);
  const [actualPosition, setActualPosition] = useState("");
  const [showUpdateModal, setShowUpdateModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleViewPrediction = (prediction) => {
    setSelectedPrediction(prediction);
  };

  const handleUpdateClick = (prediction) => {
    setSelectedPrediction(prediction);
    setActualPosition("");
    setShowUpdateModal(true);
  };

  const handleDeleteClick = (prediction) => {
    setSelectedPrediction(prediction);
    setShowDeleteModal(true);
  };

  const handleUpdateSubmit = async (e) => {
    e.preventDefault();
    if (!actualPosition) return;
    
    setIsSubmitting(true);
    try {
      await updatePredictionResult(selectedPrediction.id, Number(actualPosition));
      setShowUpdateModal(false);
      fetchPredictions(); // Refresh the predictions list
    } catch (error) {
      console.error("Error updating prediction:", error);
      alert("Failed to update prediction. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeleteConfirm = async () => {
    setIsSubmitting(true);
    try {
      await deletePrediction(selectedPrediction.id);
      setShowDeleteModal(false);
      fetchPredictions(); // Refresh the predictions list
    } catch (error) {
      console.error("Error deleting prediction:", error);
      alert("Failed to delete prediction. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Prediction History</h1>
      
      {loading && <div className="text-center py-8">Loading predictions...</div>}
      
      {error && (
        <div className="bg-red-100 border-l-4 border-red-500 p-4 mb-6">
          <p className="text-red-700">{error}</p>
        </div>
      )}
      
      {!loading && !error && (
        <div className="card mb-6">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-2xl font-bold">Your Predictions</h2>
            <div className="flex space-x-2">
              <button className="btn bg-gray-200 hover:bg-gray-300 text-gray-800">
                Export CSV
              </button>
              <Link href="/predict" className="btn btn-primary">
                New Prediction
              </Link>
            </div>
          </div>
          
          {predictions.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Date
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Horse
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Track
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Predicted
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Actual
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Odds
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Result
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {predictions.map((prediction) => (
                    <tr key={prediction.id}>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {prediction.date}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                        {prediction.horseName}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {prediction.track}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {prediction.predictedPosition}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {prediction.actualPosition || "-"}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {prediction.odds}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        {prediction.result ? (
                          <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                            ${prediction.result === 'win' ? 'bg-green-100 text-green-800' : 
                              prediction.result === 'place' ? 'bg-blue-100 text-blue-800' : 
                              'bg-red-100 text-red-800'}`}>
                            {prediction.result === 'win' ? 'Win' : 
                             prediction.result === 'place' ? 'Place' : 'Loss'}
                          </span>
                        ) : (
                          <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-gray-100 text-gray-800">
                            Pending
                          </span>
                        )}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        <button 
                          className="text-blue-600 hover:text-blue-900 mr-3"
                          onClick={() => handleViewPrediction(prediction)}
                        >
                          View
                        </button>
                        {!prediction.actualPosition && (
                          <button 
                            className="text-green-600 hover:text-green-900 mr-3"
                            onClick={() => handleUpdateClick(prediction)}
                          >
                            Update
                          </button>
                        )}
                        <button 
                          className="text-red-600 hover:text-red-900"
                          onClick={() => handleDeleteClick(prediction)}
                        >
                          Delete
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="text-center py-8">
              <p className="text-gray-500 mb-4">You haven't made any predictions yet.</p>
              <Link href="/predict" className="btn btn-primary">
                Make Your First Prediction
              </Link>
            </div>
          )}
        </div>
      )}
      
      {metrics && (
        <div className="card">
          <h2 className="text-2xl font-bold mb-4">Performance Summary</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            <div className="bg-blue-50 p-4 rounded-lg border border-blue-100">
              <p className="text-sm text-gray-500 mb-1">Total Predictions</p>
              <p className="text-2xl font-bold">{metrics.totalPredictions}</p>
            </div>
            <div className="bg-green-50 p-4 rounded-lg border border-green-100">
              <p className="text-sm text-gray-500 mb-1">Success Rate</p>
              <p className="text-2xl font-bold">
                {metrics.successRate.toFixed(2)}%
              </p>
            </div>
            <div className="bg-yellow-50 p-4 rounded-lg border border-yellow-100">
              <p className="text-sm text-gray-500 mb-1">Average Odds</p>
              <p className="text-2xl font-bold">
                {metrics.averageOdds.toFixed(2)}
              </p>
            </div>
          </div>
          
          <div className="bg-gray-50 p-4 rounded-lg">
            <h3 className="font-semibold mb-2">ROI Calculation</h3>
            <p className="text-gray-600 mb-4">
              Based on your prediction history, if you had placed a $10 bet on each prediction:
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-gray-500">Total Investment</p>
                <p className="text-xl font-bold">${metrics.totalInvestment.toFixed(2)}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Total Returns</p>
                <p className="text-xl font-bold">
                  ${metrics.totalReturns.toFixed(2)}
                </p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Profit/Loss</p>
                <p className={`text-xl font-bold ${
                  metrics.profitLoss >= 0 ? 'text-green-600' : 'text-red-600'
                }`}>
                  ${metrics.profitLoss.toFixed(2)}
                </p>
              </div>
              <div>
                <p className="text-sm text-gray-500">ROI</p>
                <p className={`text-xl font-bold ${
                  metrics.roi >= 0 ? 'text-green-600' : 'text-red-600'
                }`}>
                  {metrics.roi.toFixed(2)}%
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
      
      {/* Update Modal */}
      {showUpdateModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full">
            <h3 className="text-xl font-bold mb-4">Update Race Result</h3>
            <p className="mb-4">
              Enter the actual finishing position for {selectedPrediction.horseName}:
            </p>
            <form onSubmit={handleUpdateSubmit}>
              <div className="form-group">
                <label htmlFor="actualPosition" className="form-label">Actual Position</label>
                <input 
                  type="number" 
                  id="actualPosition" 
                  className="form-input" 
                  min="1" 
                  value={actualPosition}
                  onChange={(e) => setActualPosition(e.target.value)}
                  required
                />
              </div>
              <div className="mt-6 flex justify-end space-x-2">
                <button 
                  type="button" 
                  className="btn bg-gray-300 hover:bg-gray-400 text-gray-800"
                  onClick={() => setShowUpdateModal(false)}
                >
                  Cancel
                </button>
                <button 
                  type="submit"
                  className="btn btn-primary"
                  disabled={isSubmitting}
                >
                  {isSubmitting ? "Updating..." : "Update Result"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      
      {/* Delete Modal */}
      {showDeleteModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full">
            <h3 className="text-xl font-bold mb-4">Confirm Deletion</h3>
            <p className="mb-4">
              Are you sure you want to delete the prediction for {selectedPrediction.horseName}?
              This action cannot be undone.
            </p>
            <div className="mt-6 flex justify-end space-x-2">
              <button 
                type="button" 
                className="btn bg-gray-300 hover:bg-gray-400 text-gray-800"
                onClick={() => setShowDeleteModal(false)}
              >
                Cancel
              </button>
              <button 
                type="button"
                className="btn bg-red-600 hover:bg-red-700 text-white"
                onClick={handleDeleteConfirm}
                disabled={isSubmitting}
              >
                {isSubmitting ? "Deleting..." : "Delete Prediction"}
              </button>
            </div>
          </div>
        </div>
      )}
      
      {/* View Prediction Modal */}
      {selectedPrediction && !showUpdateModal && !showDeleteModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-3xl w-full max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-start mb-4">
              <h3 className="text-xl font-bold">Prediction Details</h3>
              <button 
                className="text-gray-500 hover:text-gray-700"
                onClick={() => setSelectedPrediction(null)}
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-semibold text-lg mb-2">Race Information</h4>
                <div className="bg-gray-50 p-4 rounded-lg">
                  <p><span className="font-medium">Date:</span> {selectedPrediction.date}</p>
                  <p><span className="font-medium">Track:</span> {selectedPrediction.track}</p>
                  <p><span className="font-medium">Class:</span> {selectedPrediction.input.race.race_class}</p>
                  <p><span className="font-medium">Distance:</span> {selectedPrediction.input.race.distance}m</p>
                  <p><span className="font-medium">Condition:</span> {selectedPrediction.input.race.track_condition}</p>
                </div>
              </div>
              
              <div>
                <h4 className="font-semibold text-lg mb-2">Horse Information</h4>
                <div className="bg-gray-50 p-4 rounded-lg">
                  <p><span className="font-medium">Name:</span> {selectedPrediction.horseName}</p>
                  <p><span className="font-medium">Barrier:</span> {selectedPrediction.input.horse.barrier}</p>
                  <p><span className="font-medium">Weight:</span> {selectedPrediction.input.horse.weight}kg</p>
                  <p><span className="font-medium">Career Record:</span> {selectedPrediction.input.horse.career_wins}/{selectedPrediction.input.horse.career_runs}</p>
                  <p><span className="font-medium">Last 5 Positions:</span> {selectedPrediction.input.horse.last_5_positions}</p>
                </div>
              </div>
              
              <div>
                <h4 className="font-semibold text-lg mb-2">Jockey & Trainer</h4>
                <div className="bg-gray-50 p-4 rounded-lg">
                  <p><span className="font-medium">Jockey:</span> {selectedPrediction.input.jockeyTrainer.jockey_name}</p>
                  <p><span className="font-medium">Jockey Record:</span> {selectedPrediction.input.jockeyTrainer.jockey_wins}/{selectedPrediction.input.jockeyTrainer.jockey_runs}</p>
                  <p><span className="font-medium">Trainer:</span> {selectedPrediction.input.jockeyTrainer.trainer_name}</p>
                  <p><span className="font-medium">Trainer Record:</span> {selectedPrediction.input.jockeyTrainer.trainer_wins}/{selectedPrediction.input.jockeyTrainer.trainer_runs}</p>
                  <p><span className="font-medium">Odds:</span> {selectedPrediction.odds}</p>
                </div>
              </div>
              
              <div>
                <h4 className="font-semibold text-lg mb-2">Prediction Results</h4>
                <div className="bg-blue-50 p-4 rounded-lg border border-blue-100">
                  <p><span className="font-medium">Predicted Position:</span> {selectedPrediction.predictedPosition}</p>
                  <p><span className="font-medium">Confidence:</span> {selectedPrediction.output.confidence}%</p>
                  <p><span className="font-medium">Recommended Bet:</span> {selectedPrediction.output.recommendedBet}</p>
                  <p><span className="font-medium">Expected ROI:</span> {selectedPrediction.output.expectedROI}%</p>
                  <p><span className="font-medium">Actual Position:</span> {selectedPrediction.actualPosition || "Not recorded"}</p>
                  <p><span className="font-medium">Result:</span> {
                    selectedPrediction.result 
                      ? (selectedPrediction.result === 'win' 
                          ? 'Win' 
                          : selectedPrediction.result === 'place' 
                            ? 'Place' 
                            : 'Loss')
                      : "Pending"
                  }</p>
                </div>
              </div>
            </div>
            
            <div className="mt-6">
              <h4 className="font-semibold text-lg mb-2">Key Factors</h4>
              <ul className="list-disc pl-5 space-y-1">
                {selectedPrediction.output.keyFactors.map((factor, index) => (
                  <li key={index}>{factor}</li>
                ))}
              </ul>
            </div>
            
            <div className="mt-6 flex justify-end">
              <button 
                className="btn bg-gray-300 hover:bg-gray-400 text-gray-800"
                onClick={() => setSelectedPrediction(null)}
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
