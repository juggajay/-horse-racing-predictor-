// src/lib/monitoring.ts
"use client";

/**
 * Simple client-side error monitoring and logging system
 */
export class ErrorMonitor {
  private static instance: ErrorMonitor;
  private errors: Array<{
    message: string;
    source: string;
    timestamp: Date;
    stack?: string;
    additionalInfo?: any;
  }> = [];
  private isInitialized = false;

  private constructor() {}

  /**
   * Get the singleton instance of ErrorMonitor
   */
  public static getInstance(): ErrorMonitor {
    if (!ErrorMonitor.instance) {
      ErrorMonitor.instance = new ErrorMonitor();
    }
    return ErrorMonitor.instance;
  }

  /**
   * Initialize the error monitoring system
   */
  public initialize(): void {
    if (this.isInitialized) return;
    
    // Set up global error handler
    if (typeof window !== 'undefined') {
      window.addEventListener('error', (event) => {
        this.logError({
          message: event.message,
          source: 'window.onerror',
          stack: event.error?.stack,
          additionalInfo: {
            filename: event.filename,
            lineno: event.lineno,
            colno: event.colno
          }
        });
      });

      // Set up unhandled promise rejection handler
      window.addEventListener('unhandledrejection', (event) => {
        this.logError({
          message: event.reason?.message || 'Unhandled Promise Rejection',
          source: 'unhandledrejection',
          stack: event.reason?.stack,
          additionalInfo: event.reason
        });
      });
    }

    this.isInitialized = true;
    console.log('Error monitoring initialized');
  }

  /**
   * Log an error to the monitoring system
   */
  public logError({
    message,
    source,
    stack,
    additionalInfo
  }: {
    message: string;
    source: string;
    stack?: string;
    additionalInfo?: any;
  }): void {
    const error = {
      message,
      source,
      timestamp: new Date(),
      stack,
      additionalInfo
    };

    this.errors.push(error);
    console.error('Error logged:', error);

    // In a real application, you would send this to a server or service
    // For now, we'll just store it locally and log to console
    this.saveErrorsToLocalStorage();
  }

  /**
   * Get all logged errors
   */
  public getErrors() {
    return [...this.errors];
  }

  /**
   * Clear all logged errors
   */
  public clearErrors() {
    this.errors = [];
    this.saveErrorsToLocalStorage();
  }

  /**
   * Save errors to localStorage for persistence
   */
  private saveErrorsToLocalStorage() {
    if (typeof window !== 'undefined') {
      try {
        localStorage.setItem('errorLogs', JSON.stringify(this.errors));
      } catch (e) {
        console.error('Failed to save errors to localStorage:', e);
      }
    }
  }

  /**
   * Load errors from localStorage
   */
  public loadErrorsFromLocalStorage() {
    if (typeof window !== 'undefined') {
      try {
        const storedErrors = localStorage.getItem('errorLogs');
        if (storedErrors) {
          this.errors = JSON.parse(storedErrors);
        }
      } catch (e) {
        console.error('Failed to load errors from localStorage:', e);
      }
    }
  }
}

/**
 * Performance monitoring for tracking page load and interaction metrics
 */
export class PerformanceMonitor {
  private static instance: PerformanceMonitor;
  private metrics: Array<{
    name: string;
    value: number;
    timestamp: Date;
    additionalInfo?: any;
  }> = [];

  private constructor() {}

  /**
   * Get the singleton instance of PerformanceMonitor
   */
  public static getInstance(): PerformanceMonitor {
    if (!PerformanceMonitor.instance) {
      PerformanceMonitor.instance = new PerformanceMonitor();
    }
    return PerformanceMonitor.instance;
  }

  /**
   * Initialize performance monitoring
   */
  public initialize(): void {
    if (typeof window !== 'undefined') {
      // Track page load performance
      window.addEventListener('load', () => {
        setTimeout(() => {
          this.trackPageLoadPerformance();
        }, 0);
      });
    }
  }

  /**
   * Track page load performance metrics
   */
  private trackPageLoadPerformance(): void {
    if (typeof window !== 'undefined' && window.performance) {
      const perfData = window.performance.timing;
      
      // Calculate key metrics
      const pageLoadTime = perfData.loadEventEnd - perfData.navigationStart;
      const domReadyTime = perfData.domComplete - perfData.domLoading;
      const networkLatency = perfData.responseEnd - perfData.requestStart;
      
      this.logMetric({
        name: 'pageLoadTime',
        value: pageLoadTime,
        additionalInfo: {
          domReadyTime,
          networkLatency,
          url: window.location.href
        }
      });
    }
  }

  /**
   * Log a performance metric
   */
  public logMetric({
    name,
    value,
    additionalInfo
  }: {
    name: string;
    value: number;
    additionalInfo?: any;
  }): void {
    const metric = {
      name,
      value,
      timestamp: new Date(),
      additionalInfo
    };

    this.metrics.push(metric);
    console.log('Performance metric logged:', metric);

    // In a real application, you would send this to a server or service
    this.saveMetricsToLocalStorage();
  }

  /**
   * Get all logged metrics
   */
  public getMetrics() {
    return [...this.metrics];
  }

  /**
   * Clear all logged metrics
   */
  public clearMetrics() {
    this.metrics = [];
    this.saveMetricsToLocalStorage();
  }

  /**
   * Save metrics to localStorage for persistence
   */
  private saveMetricsToLocalStorage() {
    if (typeof window !== 'undefined') {
      try {
        localStorage.setItem('performanceMetrics', JSON.stringify(this.metrics));
      } catch (e) {
        console.error('Failed to save metrics to localStorage:', e);
      }
    }
  }

  /**
   * Load metrics from localStorage
   */
  public loadMetricsFromLocalStorage() {
    if (typeof window !== 'undefined') {
      try {
        const storedMetrics = localStorage.getItem('performanceMetrics');
        if (storedMetrics) {
          this.metrics = JSON.parse(storedMetrics);
        }
      } catch (e) {
        console.error('Failed to load metrics from localStorage:', e);
      }
    }
  }

  /**
   * Track a user interaction
   */
  public trackInteraction(interactionType: string, details?: any) {
    this.logMetric({
      name: `interaction_${interactionType}`,
      value: performance.now(),
      additionalInfo: {
        details,
        url: typeof window !== 'undefined' ? window.location.href : ''
      }
    });
  }
}

/**
 * Initialize both monitoring systems
 */
export function initializeMonitoring() {
  if (typeof window !== 'undefined') {
    const errorMonitor = ErrorMonitor.getInstance();
    errorMonitor.initialize();
    errorMonitor.loadErrorsFromLocalStorage();

    const performanceMonitor = PerformanceMonitor.getInstance();
    performanceMonitor.initialize();
    performanceMonitor.loadMetricsFromLocalStorage();

    console.log('Monitoring systems initialized');
  }
}
