// src/lib/types.ts
export interface RaceData {
  track: string;
  race_class: string;
  distance: number;
  track_condition: string;
  race_date: string;
}

export interface HorseData {
  horse_name: string;
  barrier: number;
  weight: number;
  previous_weight: number;
  days_since_last_race: number;
  career_wins: number;
  career_runs: number;
  last_5_positions: string;
}

export interface JockeyTrainerData {
  jockey_name: string;
  trainer_name: string;
  jockey_wins: number;
  jockey_runs: number;
  trainer_wins: number;
  trainer_runs: number;
  sp_odds: number;
}

export interface PredictionInput {
  race: RaceData;
  horse: HorseData;
  jockeyTrainer: JockeyTrainerData;
}

export interface PredictionResult {
  predictedPosition: number;
  confidence: number;
  recommendedBet: string;
  expectedROI: number;
  keyFactors: string[];
}

export interface SavedPrediction {
  id: string;
  date: string;
  horseName: string;
  track: string;
  predictedPosition: number;
  actualPosition?: number;
  odds: number;
  result?: 'win' | 'place' | 'loss';
  input: PredictionInput;
  output: PredictionResult;
}
