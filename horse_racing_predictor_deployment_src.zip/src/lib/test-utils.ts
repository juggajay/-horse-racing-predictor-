// src/lib/test-utils.ts
import { PredictionInput } from './types';

/**
 * Generates a sample prediction input for testing
 */
export function generateSamplePredictionInput(): PredictionInput {
  return {
    race: {
      track: 'track1',
      race_class: 'BM70',
      distance: 1400,
      track_condition: 'Good4',
      race_date: new Date().toISOString().split('T')[0]
    },
    horse: {
      horse_name: 'Test Horse',
      barrier: 4,
      weight: 56.5,
      previous_weight: 57.0,
      days_since_last_race: 14,
      career_wins: 3,
      career_runs: 12,
      last_5_positions: '3,5,2,4,1'
    },
    jockeyTrainer: {
      jockey_name: 'Test Jockey',
      trainer_name: 'Test Trainer',
      jockey_wins: 120,
      jockey_runs: 500,
      trainer_wins: 85,
      trainer_runs: 340,
      sp_odds: 5.5
    }
  };
}

/**
 * Validates a prediction input object
 * @param input The prediction input to validate
 * @returns An object containing validation result and any error messages
 */
export function validatePredictionInput(input: PredictionInput): { isValid: boolean; errors: string[] } {
  const errors: string[] = [];

  // Validate race data
  if (!input.race.track) errors.push('Track is required');
  if (!input.race.race_class) errors.push('Race class is required');
  if (!input.race.distance || input.race.distance < 1200 || input.race.distance > 1600) {
    errors.push('Distance must be between 1200m and 1600m');
  }
  if (!input.race.track_condition) errors.push('Track condition is required');
  if (!input.race.race_date) errors.push('Race date is required');

  // Validate horse data
  if (!input.horse.horse_name) errors.push('Horse name is required');
  if (!input.horse.barrier || input.horse.barrier < 1) errors.push('Valid barrier position is required');
  if (!input.horse.weight || input.horse.weight < 45 || input.horse.weight > 65) {
    errors.push('Weight must be between 45kg and 65kg');
  }
  if (!input.horse.previous_weight || input.horse.previous_weight < 45 || input.horse.previous_weight > 65) {
    errors.push('Previous weight must be between 45kg and 65kg');
  }
  if (input.horse.days_since_last_race === undefined || input.horse.days_since_last_race < 0) {
    errors.push('Days since last race must be 0 or greater');
  }
  if (input.horse.career_wins === undefined || input.horse.career_wins < 0) {
    errors.push('Career wins must be 0 or greater');
  }
  if (input.horse.career_runs === undefined || input.horse.career_runs < 0) {
    errors.push('Career runs must be 0 or greater');
  }
  if (input.horse.career_wins > input.horse.career_runs) {
    errors.push('Career wins cannot exceed career runs');
  }
  if (!input.horse.last_5_positions) errors.push('Last 5 positions are required');

  // Validate jockey/trainer data
  if (!input.jockeyTrainer.jockey_name) errors.push('Jockey name is required');
  if (!input.jockeyTrainer.trainer_name) errors.push('Trainer name is required');
  if (input.jockeyTrainer.jockey_wins === undefined || input.jockeyTrainer.jockey_wins < 0) {
    errors.push('Jockey wins must be 0 or greater');
  }
  if (input.jockeyTrainer.jockey_runs === undefined || input.jockeyTrainer.jockey_runs < 0) {
    errors.push('Jockey runs must be 0 or greater');
  }
  if (input.jockeyTrainer.jockey_wins > input.jockeyTrainer.jockey_runs) {
    errors.push('Jockey wins cannot exceed jockey runs');
  }
  if (input.jockeyTrainer.trainer_wins === undefined || input.jockeyTrainer.trainer_wins < 0) {
    errors.push('Trainer wins must be 0 or greater');
  }
  if (input.jockeyTrainer.trainer_runs === undefined || input.jockeyTrainer.trainer_runs < 0) {
    errors.push('Trainer runs must be 0 or greater');
  }
  if (input.jockeyTrainer.trainer_wins > input.jockeyTrainer.trainer_runs) {
    errors.push('Trainer wins cannot exceed trainer runs');
  }
  if (!input.jockeyTrainer.sp_odds || input.jockeyTrainer.sp_odds < 1) {
    errors.push('Starting price odds must be 1 or greater');
  }

  return {
    isValid: errors.length === 0,
    errors
  };
}
