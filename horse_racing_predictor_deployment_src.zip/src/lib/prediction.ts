// src/lib/prediction.ts
import { PredictionInput, PredictionResult } from './types';

// Feature engineering functions
const calculateWinPercentage = (wins: number, runs: number): number => {
  if (runs === 0) return 0;
  return (wins / runs) * 100;
};

const parseLastPositions = (positionsStr: string): number[] => {
  try {
    return positionsStr.split(',').map(p => parseInt(p.trim(), 10));
  } catch (error) {
    return [];
  }
};

const calculateAveragePosition = (positions: number[]): number => {
  if (positions.length === 0) return 0;
  return positions.reduce((sum, pos) => sum + pos, 0) / positions.length;
};

const calculateWeightChange = (currentWeight: number, previousWeight: number): number => {
  return currentWeight - previousWeight;
};

const calculateBarrierAdvantage = (barrier: number, track: string, distance: number): number => {
  // Simplified barrier advantage calculation
  // In a real implementation, this would use historical data for each track/distance
  if (distance <= 1300) {
    // Inside barriers tend to be advantageous for shorter distances
    return barrier <= 5 ? 0.8 : barrier <= 10 ? 0.5 : 0.3;
  } else {
    // Middle barriers tend to be better for longer distances
    return barrier >= 3 && barrier <= 8 ? 0.7 : barrier <= 12 ? 0.5 : 0.3;
  }
};

// Main prediction function
export const generatePrediction = (input: PredictionInput): PredictionResult => {
  // Extract input data
  const { race, horse, jockeyTrainer } = input;
  
  // Feature engineering
  const horseWinPercentage = calculateWinPercentage(horse.career_wins, horse.career_runs);
  const jockeyWinPercentage = calculateWinPercentage(jockeyTrainer.jockey_wins, jockeyTrainer.jockey_runs);
  const trainerWinPercentage = calculateWinPercentage(jockeyTrainer.trainer_wins, jockeyTrainer.trainer_runs);
  const jockeyTrainerSynergy = (jockeyWinPercentage * trainerWinPercentage) / 100;
  
  const lastPositions = parseLastPositions(horse.last_5_positions);
  const averageLastPosition = calculateAveragePosition(lastPositions);
  
  const weightChange = calculateWeightChange(horse.weight, horse.previous_weight);
  const barrierAdvantage = calculateBarrierAdvantage(horse.barrier, race.track, race.distance);
  
  // Calculate prediction score (lower is better)
  // This is a simplified model - in reality, we would use the trained ML model
  let predictionScore = 0;
  
  // Weight factors based on importance
  predictionScore += averageLastPosition * 0.3;
  predictionScore -= horseWinPercentage * 0.02;
  predictionScore -= jockeyWinPercentage * 0.01;
  predictionScore -= trainerWinPercentage * 0.01;
  predictionScore -= jockeyTrainerSynergy * 0.05;
  predictionScore += weightChange * 0.2;
  predictionScore -= barrierAdvantage * 2;
  predictionScore += horse.days_since_last_race > 30 ? 1 : horse.days_since_last_race < 7 ? 0.5 : 0;
  
  // Adjust for track condition
  if (race.track_condition.includes('Heavy') && lastPositions.some(p => p <= 3)) {
    predictionScore -= 0.5; // Bonus for horses that perform well in heavy conditions
  }
  
  // Convert score to predicted position (capped at 15)
  const predictedPosition = Math.max(1, Math.min(15, Math.round(predictionScore + 1)));
  
  // Calculate confidence (higher is better)
  const confidence = Math.round(Math.max(0, Math.min(100, 100 - (predictionScore * 10))));
  
  // Determine betting recommendation
  let recommendedBet = 'No Bet';
  let expectedROI = 0;
  
  if (predictedPosition === 1 && confidence > 60) {
    recommendedBet = 'Win';
    expectedROI = 120 + (confidence - 60) * 2;
  } else if (predictedPosition <= 2 && confidence > 50) {
    recommendedBet = 'Win/Place';
    expectedROI = 80 + (confidence - 50) * 2;
  } else if (predictedPosition <= 3 && confidence > 40) {
    recommendedBet = 'Place';
    expectedROI = 40 + (confidence - 40) * 2;
  }
  
  // Identify key factors
  const keyFactors: string[] = [];
  
  if (averageLastPosition < 4) {
    keyFactors.push('Strong recent form');
  }
  
  if (weightChange < 0) {
    keyFactors.push('Weight drop from previous race');
  } else if (weightChange > 0.5) {
    keyFactors.push('Weight increase is a concern');
  }
  
  if (barrierAdvantage > 0.6) {
    keyFactors.push('Good barrier position');
  } else if (barrierAdvantage < 0.4) {
    keyFactors.push('Unfavorable barrier position');
  }
  
  if (jockeyWinPercentage > 20) {
    keyFactors.push('Jockey has high win rate');
  }
  
  if (jockeyTrainerSynergy > 5) {
    keyFactors.push('Strong jockey/trainer combination');
  }
  
  if (horse.days_since_last_race > 30) {
    keyFactors.push('Long break since last race');
  } else if (horse.days_since_last_race < 7) {
    keyFactors.push('Short turnaround from last race');
  }
  
  if (race.track_condition.includes('Heavy') && lastPositions.some(p => p <= 3)) {
    keyFactors.push('Performs well in wet conditions');
  }
  
  return {
    predictedPosition,
    confidence,
    recommendedBet,
    expectedROI,
    keyFactors
  };
};
