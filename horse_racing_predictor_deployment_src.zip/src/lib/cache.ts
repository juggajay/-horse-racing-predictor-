// src/lib/cache.ts
"use client";

/**
 * Simple in-memory cache implementation
 */
export class MemoryCache {
  private cache: Map<string, { value: any; expiry: number | null }>;
  
  constructor() {
    this.cache = new Map();
  }
  
  /**
   * Set a value in the cache
   * @param key Cache key
   * @param value Value to store
   * @param ttlSeconds Time to live in seconds (null for no expiry)
   */
  set(key: string, value: any, ttlSeconds: number | null = 300): void {
    const expiry = ttlSeconds ? Date.now() + (ttlSeconds * 1000) : null;
    this.cache.set(key, { value, expiry });
  }
  
  /**
   * Get a value from the cache
   * @param key Cache key
   * @returns The cached value or null if not found or expired
   */
  get(key: string): any {
    const item = this.cache.get(key);
    
    // Not found
    if (!item) return null;
    
    // Check if expired
    if (item.expiry && item.expiry < Date.now()) {
      this.cache.delete(key);
      return null;
    }
    
    return item.value;
  }
  
  /**
   * Remove a value from the cache
   * @param key Cache key
   */
  delete(key: string): void {
    this.cache.delete(key);
  }
  
  /**
   * Clear all values from the cache
   */
  clear(): void {
    this.cache.clear();
  }
  
  /**
   * Get all keys in the cache
   * @returns Array of cache keys
   */
  keys(): string[] {
    return Array.from(this.cache.keys());
  }
}

// Create a singleton instance
export const memoryCache = new MemoryCache();

/**
 * Wrapper for async functions to cache their results
 * @param fn Function to cache
 * @param keyFn Function to generate cache key from arguments
 * @param ttlSeconds Time to live in seconds
 * @returns Cached function
 */
export function withCache<T extends (...args: any[]) => Promise<any>>(
  fn: T,
  keyFn: (...args: Parameters<T>) => string,
  ttlSeconds: number = 300
): (...args: Parameters<T>) => Promise<ReturnType<T>> {
  return async (...args: Parameters<T>): Promise<ReturnType<T>> => {
    const key = keyFn(...args);
    const cached = memoryCache.get(key);
    
    if (cached !== null) {
      return cached as ReturnType<T>;
    }
    
    const result = await fn(...args);
    memoryCache.set(key, result, ttlSeconds);
    return result;
  };
}
