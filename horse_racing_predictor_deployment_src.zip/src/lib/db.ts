// src/lib/db.ts
import { SavedPrediction } from './types';

// Mock database for predictions
let predictions: SavedPrediction[] = [
  {
    id: '1',
    date: '2025-03-15',
    horseName: 'Thunder Bolt',
    track: 'Track 1',
    predictedPosition: 2,
    actualPosition: 1,
    odds: 5.5,
    result: 'win',
    input: {
      race: {
        track: 'track1',
        race_class: 'BM70',
        distance: 1400,
        track_condition: 'Good4',
        race_date: '2025-03-15'
      },
      horse: {
        horse_name: 'Thunder Bolt',
        barrier: 4,
        weight: 56.5,
        previous_weight: 57.0,
        days_since_last_race: 14,
        career_wins: 3,
        career_runs: 12,
        last_5_positions: '3,5,2,4,1'
      },
      jockeyTrainer: {
        jockey_name: 'John Smith',
        trainer_name: 'Mike Johnson',
        jockey_wins: 120,
        jockey_runs: 500,
        trainer_wins: 85,
        trainer_runs: 340,
        sp_odds: 5.5
      }
    },
    output: {
      predictedPosition: 2,
      confidence: 68,
      recommendedBet: 'Win/Place',
      expectedROI: 120,
      keyFactors: [
        'Strong recent form',
        'Weight drop from previous race',
        'Good barrier position',
        'Jockey has high win rate at this track'
      ]
    }
  },
  {
    id: '2',
    date: '2025-03-10',
    horseName: 'Silver Streak',
    track: 'Track 3',
    predictedPosition: 1,
    actualPosition: 3,
    odds: 3.2,
    result: 'place',
    input: {
      race: {
        track: 'track3',
        race_class: 'BM64',
        distance: 1200,
        track_condition: 'Good3',
        race_date: '2025-03-10'
      },
      horse: {
        horse_name: 'Silver Streak',
        barrier: 2,
        weight: 54.0,
        previous_weight: 54.0,
        days_since_last_race: 21,
        career_wins: 2,
        career_runs: 8,
        last_5_positions: '1,4,2,3,5'
      },
      jockeyTrainer: {
        jockey_name: 'Sarah Williams',
        trainer_name: 'David Brown',
        jockey_wins: 85,
        jockey_runs: 420,
        trainer_wins: 110,
        trainer_runs: 480,
        sp_odds: 3.2
      }
    },
    output: {
      predictedPosition: 1,
      confidence: 72,
      recommendedBet: 'Win',
      expectedROI: 150,
      keyFactors: [
        'Consistent performer',
        'Ideal distance',
        'Favorable track condition',
        'Strong jockey/trainer combination'
      ]
    }
  },
  {
    id: '3',
    date: '2025-03-05',
    horseName: 'Golden Arrow',
    track: 'Track 2',
    predictedPosition: 3,
    actualPosition: 7,
    odds: 8.0,
    result: 'loss',
    input: {
      race: {
        track: 'track2',
        race_class: 'BM76',
        distance: 1600,
        track_condition: 'Soft6',
        race_date: '2025-03-05'
      },
      horse: {
        horse_name: 'Golden Arrow',
        barrier: 8,
        weight: 58.0,
        previous_weight: 57.5,
        days_since_last_race: 7,
        career_wins: 4,
        career_runs: 15,
        last_5_positions: '2,1,6,4,3'
      },
      jockeyTrainer: {
        jockey_name: 'Tom Davis',
        trainer_name: 'Robert Wilson',
        jockey_wins: 95,
        jockey_runs: 450,
        trainer_wins: 75,
        trainer_runs: 320,
        sp_odds: 8.0
      }
    },
    output: {
      predictedPosition: 3,
      confidence: 55,
      recommendedBet: 'Place',
      expectedROI: 80,
      keyFactors: [
        'Good at this distance',
        'Weight increase is a concern',
        'Short turnaround from last race',
        'Track condition not ideal'
      ]
    }
  }
];

// Get all predictions
export const getAllPredictions = (): SavedPrediction[] => {
  return predictions;
};

// Get prediction by ID
export const getPredictionById = (id: string): SavedPrediction | undefined => {
  return predictions.find(p => p.id === id);
};

// Save a new prediction
export const savePrediction = (prediction: Omit<SavedPrediction, 'id'>): SavedPrediction => {
  const id = (predictions.length + 1).toString();
  const newPrediction = { ...prediction, id };
  predictions = [...predictions, newPrediction];
  return newPrediction;
};

// Update prediction with actual results
export const updatePredictionResult = (
  id: string, 
  actualPosition: number
): SavedPrediction | undefined => {
  const index = predictions.findIndex(p => p.id === id);
  if (index === -1) return undefined;
  
  const prediction = predictions[index];
  let result: 'win' | 'place' | 'loss';
  
  if (actualPosition === 1) {
    result = 'win';
  } else if (actualPosition <= 3) {
    result = 'place';
  } else {
    result = 'loss';
  }
  
  const updatedPrediction = {
    ...prediction,
    actualPosition,
    result
  };
  
  predictions = [
    ...predictions.slice(0, index),
    updatedPrediction,
    ...predictions.slice(index + 1)
  ];
  
  return updatedPrediction;
};

// Delete a prediction
export const deletePrediction = (id: string): boolean => {
  const initialLength = predictions.length;
  predictions = predictions.filter(p => p.id !== id);
  return predictions.length < initialLength;
};

// Calculate performance metrics
export const getPerformanceMetrics = () => {
  const completedPredictions = predictions.filter(p => p.result !== undefined);
  const totalPredictions = completedPredictions.length;
  
  if (totalPredictions === 0) {
    return {
      totalPredictions: 0,
      successRate: 0,
      averageOdds: 0,
      totalInvestment: 0,
      totalReturns: 0,
      profitLoss: 0,
      roi: 0
    };
  }
  
  const successfulPredictions = completedPredictions.filter(
    p => p.result === 'win' || p.result === 'place'
  );
  
  const successRate = (successfulPredictions.length / totalPredictions) * 100;
  const averageOdds = completedPredictions.reduce((sum, p) => sum + p.odds, 0) / totalPredictions;
  
  const betAmount = 10; // Assuming $10 bet on each prediction
  const totalInvestment = totalPredictions * betAmount;
  
  const totalReturns = completedPredictions.reduce((sum, p) => {
    if (p.result === 'win') {
      return sum + (p.odds * betAmount);
    }
    return sum;
  }, 0);
  
  const profitLoss = totalReturns - totalInvestment;
  const roi = (profitLoss / totalInvestment) * 100;
  
  return {
    totalPredictions,
    successRate,
    averageOdds,
    totalInvestment,
    totalReturns,
    profitLoss,
    roi
  };
};
