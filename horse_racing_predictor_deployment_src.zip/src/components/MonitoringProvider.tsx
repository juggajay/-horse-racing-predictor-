"use client";

import { useEffect } from 'react';
import { initializeMonitoring } from '@/lib/monitoring';

export function MonitoringProvider({ children }: { children: React.ReactNode }) {
  useEffect(() => {
    // Initialize monitoring on client-side only
    initializeMonitoring();
  }, []);

  return <>{children}</>;
}
